# WeirdMakerBot
Discord bot that can be used to create weirdcore

You can:
- Use the code for educational purposes
- Share this code to others, but don't forget to credit me!

You can't:
- Copy the whole code, make discord bot, and claim that it's yours (well, that was obvious)
- Share this code without crediting me
